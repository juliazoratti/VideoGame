package com.GamerStore.Loja_de_Games;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LojaDeGamesApplicationTests {

	@Test
	void contextLoads() {
	}

}
